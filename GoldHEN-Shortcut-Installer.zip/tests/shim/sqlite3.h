/* Shim minimo SO PARA TESTE NO PC (a lib do sistema nao tem header aqui).
 * No PS4 voce usa o sqlite3.h verdadeiro do amalgamation. */
#ifndef SHIM_SQLITE3_H
#define SHIM_SQLITE3_H
typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
typedef struct sqlite3_vfs sqlite3_vfs;
typedef long long sqlite3_int64;
#define SQLITE_OK 0
#define SQLITE_ROW 100
#define SQLITE_DONE 101
#define SQLITE_OPEN_READWRITE 0x00000002
#define SQLITE_STATIC ((void(*)(void*))0)
int sqlite3_open_v2(const char*, sqlite3**, int, const char*);
sqlite3_vfs *sqlite3_vfs_find(const char*);
int sqlite3_close(sqlite3*);
int sqlite3_busy_timeout(sqlite3*, int);
int sqlite3_exec(sqlite3*, const char*, int(*)(void*,int,char**,char**), void*, char**);
int sqlite3_prepare_v2(sqlite3*, const char*, int, sqlite3_stmt**, const char**);
int sqlite3_step(sqlite3_stmt*);
int sqlite3_finalize(sqlite3_stmt*);
int sqlite3_reset(sqlite3_stmt*);
int sqlite3_bind_text(sqlite3_stmt*, int, const char*, int, void(*)(void*));
int sqlite3_bind_int64(sqlite3_stmt*, int, sqlite3_int64);
const unsigned char *sqlite3_column_text(sqlite3_stmt*, int);
sqlite3_int64 sqlite3_column_int64(sqlite3_stmt*, int);
const char *sqlite3_errmsg(sqlite3*);
int sqlite3_changes(sqlite3*);
#endif
