#!/usr/bin/env python3
"""Testa o nucleo (ghen_db.c) no PC contra uma COPIA do app.db real.
Uso: python3 tests/run_tests.py caminho/do/app.db"""
import sqlite3, shutil, subprocess, sys, os, tempfile

SRC = sys.argv[1]
T = "GHEN12349"
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.dirname(here)
exe = os.path.join(tempfile.gettempdir(), "ghen_cli")
subprocess.check_call(["gcc", "-Wall", "-Wextra", "-O1", "-I", os.path.join(here, "shim"),
    os.path.join(root, "src/ghen_db.c"), os.path.join(here, "ghen_cli.c"),
    "-l:libsqlite3.so.0", "-o", exe])

def users(c):
    return [r[0].split("_")[-1] for r in c.execute(
        "select name from sqlite_master where name like 'tbl_appbrowse_%' order by name")]

def row(c, u):
    cur = c.execute(f"select * from tbl_appbrowse_{u} where titleId=?", (T,))
    cols = [d[0] for d in cur.description]
    r = cur.fetchone()
    return None if r is None else dict(zip(cols, r))

def info(c):
    return list(c.execute("select key,val,typeof(val) from tbl_appinfo where titleId=? order by key", (T,)))

def run(db, user=None):
    out = subprocess.run([exe, db] + ([user] if user else []), capture_output=True, text=True).stdout.strip()
    print("   ", out)
    return out

orig = sqlite3.connect(f"file:{SRC}?mode=ro", uri=True)
U = users(orig)
ref_info = info(orig)
ref_row = row(orig, U[1])           # linha "comum" (a mesma de 7 dos 9 usuarios)
fails = 0
def check(cond, msg):
    global fails
    print(("  OK  " if cond else "  FALHOU  ") + msg)
    fails += (not cond)

def fresh():
    d = tempfile.mkdtemp()
    p = os.path.join(d, "app.db")
    shutil.copy(SRC, p)
    return p

# ---- 1) todos os usuarios, com a entrada removida de 3 usuarios e do appinfo
print("1) TODOS os usuarios (GoldHEN removido de 3 usuarios + appinfo)")
db = fresh(); c = sqlite3.connect(db)
gone = U[1:4]
for u in gone: c.execute(f"delete from tbl_appbrowse_{u} where titleId=?", (T,))
c.execute("delete from tbl_appinfo where titleId=?", (T,)); c.commit()
before = {u: c.execute(f"select count(*), max(rowid) from tbl_appbrowse_{u}").fetchone() for u in U}
c.close()
out = run(db)
c = sqlite3.connect(db)
check("rc=0" in out and f"added={len(gone)}" in out and f"existing={len(U)-len(gone)}" in out, "relatorio: 3 adicionados, 6 ja existiam")
for u in gone:
    r = row(c, u)
    check(r == ref_row, f"{u}: linha identica a do seu app.db")
    cnt, mx = c.execute(f"select count(*), max(rowid) from tbl_appbrowse_{u}").fetchone()
    check(cnt == before[u][0] + 1 and mx == before[u][1] + 1, f"{u}: entrou embaixo da ultima linha (rowid {mx})")
check(info(c) == ref_info, "tbl_appinfo identica (36 chaves, tipos preservados)")
check(c.execute("pragma integrity_check").fetchone()[0] == "ok", "integrity_check ok")
c.close()

# ---- 2) rodar de novo: nada muda (so o icone seria trocado)
print("2) Rodar de novo (idempotente)")
h1 = subprocess.check_output(["sha256sum", db]).split()[0]
out = run(db)
h2 = subprocess.check_output(["sha256sum", db]).split()[0]
check(f"added=0" in out and f"existing={len(U)}" in out and "appinfo=0" in out, "tudo 'ja existia'")
# (o arquivo pode mudar bytes por causa do commit; conferimos o conteudo)
c = sqlite3.connect(db)
check(info(c) == ref_info and row(c, U[1]) == ref_row, "conteudo igual")
c.close()

# ---- 3) so um usuario
print("3) SO o usuario atual")
db = fresh(); c = sqlite3.connect(db)
for u in U[1:4]: c.execute(f"delete from tbl_appbrowse_{u} where titleId=?", (T,))
c.commit(); c.close()
out = run(db, U[2])
c = sqlite3.connect(db)
check("added=1" in out and "targets=1" in out, "relatorio: 1 alvo, 1 adicionado")
check(row(c, U[2]) == ref_row, f"{U[2]} recebeu")
check(row(c, U[1]) is None and row(c, U[3]) is None, "os outros removidos continuam sem")
c.close()

# ---- 4) usuario inexistente -> erro, nada alterado (rollback)
print("4) Usuario inexistente")
db = fresh(); c = sqlite3.connect(db)
c.execute("delete from tbl_appinfo where titleId=?", (T,)); c.commit(); c.close()
out = run(db, "0000000001")
c = sqlite3.connect(db)
check("rc=-1" in out and "nao tem tabela" in out, "erro reportado")
check(info(c) == [], "rollback: appinfo continua vazio")
c.close()

# ---- 5) appinfo parcial: completa sem sobrescrever o que existe
print("5) appinfo parcial")
db = fresh(); c = sqlite3.connect(db)
c.execute("update tbl_appinfo set val='MEU_TITULO' where titleId=? and key='TITLE'", (T,))
c.execute("delete from tbl_appinfo where titleId=? and key in ('_sort_priority','CATEGORY')", (T,)); c.commit(); c.close()
out = run(db)
c = sqlite3.connect(db)
d = {k: v for k, v, t in info(c)}
check("appinfo=2" in out, "so as 2 chaves faltantes foram inseridas")
check(d["TITLE"] == "MEU_TITULO", "valor existente NAO foi sobrescrito")
c.close()

print("\nRESULTADO:", "TUDO OK" if not fails else f"{fails} FALHA(S)")
sys.exit(1 if fails else 0)
