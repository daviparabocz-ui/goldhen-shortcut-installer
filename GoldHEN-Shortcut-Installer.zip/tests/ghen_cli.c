/* CLI de teste no PC: ghen_cli <app.db> [userSuffix10digitos] */
#include <stdio.h>
#include "../src/ghen_db.h"
int main(int argc, char **argv)
{
    GhenReport r;
    int rc;
    if (argc < 2) { fprintf(stderr, "uso: %s app.db [usuario]\n", argv[0]); return 2; }
    rc = ghen_db_install(argv[1], argc > 2 ? argv[2] : NULL, &r);
    printf("rc=%d found=%d targets=%d added=%d existing=%d appinfo=%d err=[%s]\n",
           rc, r.users_found, r.targets, r.added, r.existing, r.appinfo_rows, r.err);
    return rc;
}
