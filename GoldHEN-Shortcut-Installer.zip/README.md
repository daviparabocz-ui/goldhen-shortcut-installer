# GoldHEN Shortcut Installer (PS4)

PKG que adiciona o atalho **★ Enable GoldHEN** (`GHEN12349`) no `app.db`.
No app: **X** = só o usuário atual · **Quadrado** = todos os usuários · **Triângulo** = restaurar backup do `app.db` · **Círculo** = sair. Antes de instalar, X confirma e O cancela.

## O que ele faz
- Copia **exatamente** as linhas de `GHEN12349` do seu app.db (`tbl_appbrowse_*` e `tbl_appinfo`, tipos preservados) — geradas por `tools/gen_template.py` em `src/ghen_template.h`.
- Insere embaixo da última linha de cada `tbl_appbrowse_<usuário>`.
- Se o usuário já tem a entrada: não mexe na linha, só troca o `icon0.png` em `/user/appmeta/GHEN12349/`.
- Tudo numa transação (erro = nada muda). Backup do original em `/data/GHEN_Shortcut/app.db.bak` (só na 1ª vez).
- Depois de instalar, reinicie o PS4 por completo.

## Ícones
- `sce_sys/icon0.png`: ícone do instalador (com "Shortcut Installer", Carlito = clone do Calibri).
- `assets/icon0.png`: ícone do atalho/ativador (o seu original, sem texto).

## Compilar
1. `./tools/get_sqlite.sh` (baixa o sqlite3.c) · 2. `export OO_PS4_TOOLCHAIN=...` · 3. `make`
Ou suba o zip no GitHub (raiz do repo): o workflow `.github/workflows/build.yml` compila.

## IMPORTANTE (não testado no console)
- `src/jailbreak_stub.c` continua sendo um stub fraco: é necessário implementar `ps4_jailbreak()` com o método de escape do sandbox/root compatível com o firmware. Sem isso, o app não consegue abrir `/system_data/priv/mms/app.db`; GoldHEN ativo, por si só, não significa que um homebrew OpenOrbis comum tenha permissão para esse caminho.
- A parte PS4 (`main.c`, Makefile, workflow) não foi compilada aqui. O núcleo do banco (`ghen_db.c`) foi testado no PC: `python3 tests/run_tests.py app.db`.
- Passos do toolchain/URL do workflow podem precisar de ajuste na sua versão do OpenOrbis.
