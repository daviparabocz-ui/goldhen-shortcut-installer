# GoldHEN Shortcut Installer (PS4)

PKG que adiciona o atalho **★ Enable GoldHEN** (`GHEN12349`) no `app.db`.
No app: **X** = só o usuário atual · **Quadrado** = todos os usuários · **Triângulo** = restaurar backup do `app.db` · **Círculo** = sair. Antes de instalar, X confirma e O cancela.

## O que ele faz
- Copia **exatamente** as linhas de `GHEN12349` do seu app.db (`tbl_appbrowse_*` e `tbl_appinfo`, tipos preservados) — geradas por `tools/gen_template.py` em `src/ghen_template.h`.
- Insere embaixo da última linha de cada `tbl_appbrowse_<usuário>`.
- Se o usuário já tem a entrada: não mexe na linha, só troca o `icon0.png` em `/user/appmeta/GHEN12349/`.
- Tudo numa transação (erro = nada muda). Backup do original em `/data/GHEN_Shortcut/app.db.bak` (só na 1ª vez).
- Depois de instalar, reinicie o PS4 por completo.

## Acesso ao app.db
- Usa a API do GoldHEN Plugin SDK (syscall 500) para obter acesso privilegiado temporário e restaurar as credenciais originais ao terminar.
- Requer GoldHEN com suporte aos comandos `JAILBREAK` e `UNJAILBREAK` dessa API. Se a chamada falhar, o instalador para antes de acessar os arquivos protegidos.
- Não inclui exploit próprio nem funciona para contornar o sandbox sem GoldHEN.

## Ícones
- `sce_sys/icon0.png`: ícone do instalador (com "Shortcut Installer", Carlito = clone do Calibri).
- `assets/icon0.png`: ícone do atalho/ativador (o seu original, sem texto).

## Compilar
1. `./tools/get_sqlite.sh` (baixa o sqlite3.c) · 2. `export OO_PS4_TOOLCHAIN=...` · 3. `make`
Ou suba o zip no GitHub (raiz do repo): o workflow `.github/workflows/build.yml` compila.

## IMPORTANTE (não testado no console)
- A integração usa os comandos documentados `sys_sdk_jailbreak()` e `sys_sdk_unjailbreak()` do [GoldHEN Plugin SDK](https://github.com/GoldHEN/GoldHEN_Plugins_SDK). A compatibilidade precisa ser confirmada no GoldHEN/firmware instalado.
- A integração foi verificada sintaticamente, mas o PKG completo e o acesso no console não foram testados aqui. O núcleo do banco (`ghen_db.c`) pode ser testado no PC: `python3 tests/run_tests.py app.db`.
- Passos do toolchain/URL do workflow podem precisar de ajuste na sua versão do OpenOrbis.
