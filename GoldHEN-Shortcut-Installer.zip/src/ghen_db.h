/*
 * ghen_db: logica do app.db (portavel — roda no PS4 e no PC, so depende de sqlite3).
 * Nenhuma chamada especifica de PS4 aqui, para poder testar no computador.
 */
#ifndef GHEN_DB_H
#define GHEN_DB_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int  users_found;   /* tabelas tbl_appbrowse_<userId> encontradas no app.db            */
    int  targets;       /* usuarios-alvo desta execucao (1 = so o atual, N = todos)         */
    int  added;         /* usuarios que ganharam a entrada (inserida abaixo da ultima linha) */
    int  existing;      /* usuarios onde a entrada ja existia -> so o icon0 e trocado       */
    int  appinfo_rows;  /* linhas novas em tbl_appinfo (0 se ja estava completo)            */
    char err[256];      /* mensagem de erro (vazia se tudo ok)                              */
} GhenReport;

/* userId (int do PS4) -> sufixo de 10 digitos usado nas tabelas, ex.: 408597777 -> "0408597777" */
void ghen_user_suffix(int userId, char out[11]);

/*
 * Instala o atalho no app.db.
 *   onlyUser == NULL        -> todos os usuarios (todas as tbl_appbrowse_*)
 *   onlyUser == "0408597777" -> so esse usuario (a tabela precisa existir)
 * Tudo roda numa transacao: se algo falhar, nada e alterado.
 * Retorna 0 em sucesso; senao != 0 e rep->err preenchido.
 */
int ghen_db_install(const char *dbPath, const char *onlyUser, GhenReport *rep);

#ifdef __cplusplus
}
#endif
#endif
