/* STREAMING_CHUNK:Defining includes and prototypes... /
/

GoldHEN Shortcut Installer — PS4 (OpenOrbis)

X = so o usuario atual | Quadrado = todos os usuarios | Triangulo = restaurar app.db | Circulo = sair

Fluxo: select mode -> root/jailbreak -> confirm -> backup app.db -> ghen_db_install() -> icon0 -> avisos.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>
#include <stdarg.h>

#include "ghen_db.h"
#include "ghen_template.h"

/* Prototipos por alias de simbolo: nao brigam com os headers do toolchain. */
extern int  p_notify(int dev, void *req, size_t sz, int blk) asm("sceKernelSendNotificationRequest");
extern int  p_usleep(unsigned us)                        asm("sceKernelUsleep");
extern int  p_user_init(void *p)                         asm("sceUserServiceInitialize");
extern int  p_user_fg(int *id)                           asm("sceUserServiceGetForegroundUser");
extern int  p_user_init_user(int *id)                    asm("sceUserServiceGetInitialUser");
extern int  p_pad_init(void)                             asm("scePadInit");
extern int  p_pad_open(int user, int type, int idx, void *p) asm("scePadOpen");
extern int  p_pad_read(int h, void *data)                asm("scePadReadState");
extern int  ps4_jailbreak(void);
extern int  ps4_unjailbreak(void);

#define DB_PATH    "/system_data/priv/mms/app.db"
#define BAK_DIR    "/data/GHEN_Shortcut"
#define BAK_PATH   BAK_DIR "/app.db.bak"
#define META_DIR   "/user/appmeta/" GHEN_TITLE_ID
#define ICON_SRC   "/app0/assets/icon0.png"
#define ICON_DST   META_DIR "/icon0.png"

#define BTN_TRIANGLE 0x1000u
#define BTN_CIRCLE   0x2000u
#define BTN_CROSS    0x4000u
#define BTN_SQUARE   0x8000u

typedef struct {
int type, reqId, priority, msgId, targetId, userId, unk1, unk2, appId, errorNum, unk3;
unsigned char useIconImageUri;
char message[1024], iconUri[1024], unk[1024];
} NotifReq;

/* STREAMING_CHUNK:Implementing notification and file utilities... */
static void toast(const char *fmt, ...)
{
static NotifReq r;
va_list ap;
memset(&r, 0, sizeof(r));
r.type = 0; r.targetId = -1;
va_start(ap, fmt);
vsnprintf(r.message, sizeof(r.message), fmt, ap);
va_end(ap);
p_notify(0, &r, sizeof(r), 0);
}

static int copy_file(const char *src, const char *dst)
{
char tmp[256];
FILE *in = fopen(src, "rb"), *out;
char buf[8192];
size_t n;
if (!in) return -1;
snprintf(tmp, sizeof(tmp), "%s.tmp", dst);
out = fopen(tmp, "wb");
if (!out) { fclose(in); return -2; }
while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
if (fwrite(buf, 1, n, out) != n) { fclose(in); fclose(out); remove(tmp); return -3; }
fclose(in);
fclose(out);
if (rename(tmp, dst) != 0) { remove(tmp); return -4; }
return 0;
}

static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }

/* STREAMING_CHUNK:Implementing controller pad selection mode... */
static int pick_mode(int userId)
{
static unsigned char padbuf[1024] __attribute__((aligned(16)));
int h, waited = 0;
p_pad_init();
h = p_pad_open(userId, 0, 0, NULL);
if (h < 0) { toast("Pad nao abriu (0x%x)", h); return 0; }
while (waited < 180000) {
if (waited % 9000 == 0)
toast("GoldHEN Shortcut Installer\nX = so este usuario\nQuadrado = todos os usuarios\nTriangulo = restaurar app.db\nCirculo = sair");
memset(padbuf, 0, 64);
if (p_pad_read(h, padbuf) >= 0) {
uint32_t b = *(uint32_t *)padbuf;
if (b & BTN_TRIANGLE) return 3;
if (b & BTN_CROSS) return 1;
if (b & BTN_SQUARE) return 2;
if (b & BTN_CIRCLE) return 0;
}
p_usleep(50000); waited += 50;
}
return 0;
}

/* STREAMING_CHUNK:Implementing installation confirmation... */
static int confirm_install(int userId)
{
static unsigned char padbuf[1024] __attribute__((aligned(16)));
int h, waited = 0;
p_pad_init();
h = p_pad_open(userId, 0, 0, NULL);
if (h < 0) { toast("Pad nao abriu (0x%x)", h); return 0; }
toast("Estou prestes a instalar o atalho no seu PS4. Ha risco de o banco de dados ser corrompido e suas pastas e ordens serem perdidas. Se isso acontecer, abra o instalador novamente e pressione Triangulo para restaurar o banco antes da modificacao. X = continuar; O = cancelar.");
while (waited < 60000) {
memset(padbuf, 0, 64);
if (p_pad_read(h, padbuf) >= 0) {
uint32_t b = *(uint32_t *)padbuf;
if (b & BTN_CROSS) return 1;
if (b & BTN_CIRCLE) return 0;
}
p_usleep(50000); waited += 50;
}
toast("Confirmacao expirada. Cancelado.");
return 0;
}

/* STREAMING_CHUNK:Implementing main execution routine... */
static int run_mode(int userId, int mode)
{
char suffix[11];
GhenReport rep;

/* Se o usuario escolheu restaurar o backup (Triangulo) */
if (mode == 3) {
    if (!exists(BAK_PATH)) {
        toast("Nenhum backup encontrado em %s", BAK_PATH);
        return 1;
    }
    if (copy_file(BAK_PATH, DB_PATH) != 0) {
        toast("Falha ao restaurar o app.db do backup.");
        return 1;
    }
    toast("Banco de dados restaurado com sucesso a partir do backup! Reinicie o PS4.");
    p_usleep(4000000);
    return 0;
}

if (!exists(DB_PATH)) { toast("Sem acesso ao app.db (jailbreak/permissao?)"); return 1; }

/* Confirma antes de modificar o banco */
if (!confirm_install(userId)) {
    toast("Instalacao cancelada pelo usuario.");
    return 0;
}

/* Backup so na primeira vez: guarda o app.db original */
mkdir(BAK_DIR, 0777);
if (!exists(BAK_PATH) && copy_file(DB_PATH, BAK_PATH) != 0) {
    toast("Falhou o backup do app.db. Nada foi alterado.");
    return 1;
}

ghen_user_suffix(userId, suffix);
if (ghen_db_install(DB_PATH, mode == 1 ? suffix : NULL, &rep) != 0) {
    toast("Erro no app.db: %s\nNada foi alterado.", rep.err);
    return 1;
}

/* icon0: sempre troca (a pasta appmeta e compartilhada por todos os usuarios) */
mkdir("/user/appmeta", 0777);
mkdir(META_DIR, 0777);
if (copy_file(ICON_SRC, ICON_DST) != 0) {
    toast("Atalho ok, mas falhou ao gravar o icon0.png");
    return 1;
}

toast("Pronto!\nNovos: %d | ja existiam (so icone): %d\nReinicie o PS4 por completo para ver o atalho.",
      rep.added, rep.existing);
p_usleep(4000000);
return 0;
}

int main(void)
{
int userId = -1, mode, result;

p_user_init(NULL);
if (p_user_fg(&userId) < 0 || userId <= 0) p_user_init_user(&userId);

mode = pick_mode(userId);
if (mode == 0) { toast("Cancelado."); return 0; }

if (ps4_jailbreak() < 0) {
    toast("GoldHEN nao disponibilizou acesso root. Inicie o GoldHEN e tente novamente.");
    return 1;
}

result = run_mode(userId, mode);
if (ps4_unjailbreak() < 0) {
    toast("Falha ao restaurar as credenciais originais.");
    return 1;
}

return result;

}
