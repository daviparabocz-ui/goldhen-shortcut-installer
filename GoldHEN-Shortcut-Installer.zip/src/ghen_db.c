#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <errno.h>

#include "ghen_db.h"
#include "ghen_template.h" /* GHEN_BROWSE[] / GHEN_INFO[] copiados do app.db do usuario */

#define MAX_USERS 32
#define PFX "tbl_appbrowse_"

#define DB_PATH "/system_data/priv/mms/app.db"
#define BAK_PATH "/system_data/priv/mms/app.db.bak"

static void set_err(GhenReport *r, const char *fmt, ...)
{
va_list ap;
va_start(ap, fmt);
vsnprintf(r->err, sizeof(r->err), fmt, ap);
va_end(ap);
}

void ghen_user_suffix(int userId, char out[11])
{
snprintf(out, 11, "%010u", (unsigned)userId);
}

/* "tbl_appbrowse_0408597777" -> "0408597777"; so aceita 10 digitos (tambem evita SQL injection no nome) */
static int user_from_table(const char *name, char out[11])
{
size_t pl = strlen(PFX);
if (strncmp(name, PFX, pl) != 0) return 0;
const char *u = name + pl;
if (strlen(u) != 10) return 0;
for (int i = 0; i < 10; i++)
if (!isdigit((unsigned char)u[i])) return 0;
memcpy(out, u, 10);
out[10] = 0;
return 1;
}

static int list_users(sqlite3 *db, char users[][11], int max)
{
sqlite3_stmt *st = NULL;
int n = 0;
if (sqlite3_prepare_v2(db,
"SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'tbl_appbrowse_%' ORDER BY name",
-1, &st, NULL) != SQLITE_OK)
return -1;
while (sqlite3_step(st) == SQLITE_ROW && n < max) {
char u[11];
if (user_from_table((const char *)sqlite3_column_text(st, 0), u)) {
memcpy(users[n++], u, 11);
}
}
sqlite3_finalize(st);
return n;
}

static int bind_cell(sqlite3_stmt *st, int idx, const GhenCell *c)
{
if (c->kind == 1) return sqlite3_bind_int64(st, idx, (sqlite3_int64)c->i);
return sqlite3_bind_text(st, idx, c->s, -1, SQLITE_STATIC);
}

/* 1 = existe, 0 = nao, -1 = erro */
static int entry_exists(sqlite3 *db, const char *table)
{
char sql[160];
sqlite3_stmt *st = NULL;
int found = 0;
snprintf(sql, sizeof(sql), "SELECT 1 FROM %s WHERE titleId=?1", table);
if (sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK) return -1;
sqlite3_bind_text(st, 1, GHEN_TITLE_ID, -1, SQLITE_STATIC);
if (sqlite3_step(st) == SQLITE_ROW) found = 1;
sqlite3_finalize(st);
return found;
}

/* Insere a linha logo abaixo da ultima linha (rowid = max+1). */
static int insert_browse(sqlite3 *db, const char *table, GhenReport *rep)
{
static char sql[8192];
size_t o = 0;
sqlite3_stmt *st = NULL;
sqlite3_int64 next = 1;

/* proxima posicao = embaixo da ultima linha preenchida */
snprintf(sql, sizeof(sql), "SELECT COALESCE(MAX(rowid),0)+1 FROM %s", table);
if (sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK) goto sqlfail;
if (sqlite3_step(st) == SQLITE_ROW) next = sqlite3_column_int64(st, 0);
sqlite3_finalize(st);
st = NULL;

o += snprintf(sql + o, sizeof(sql) - o, "INSERT INTO %s (rowid", table);
for (size_t i = 0; i < GHEN_BROWSE_N; i++)
    o += snprintf(sql + o, sizeof(sql) - o, ",\"%s\"", GHEN_BROWSE[i].name);
o += snprintf(sql + o, sizeof(sql) - o, ") VALUES (?1");
for (size_t i = 0; i < GHEN_BROWSE_N; i++)
    o += snprintf(sql + o, sizeof(sql) - o, ",?%d", (int)i + 2);
o += snprintf(sql + o, sizeof(sql) - o, ")");
if (o >= sizeof(sql)) { set_err(rep, "SQL grande demais"); return -1; }

if (sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK) goto sqlfail;
sqlite3_bind_int64(st, 1, next);
for (size_t i = 0; i < GHEN_BROWSE_N; i++)
    if (bind_cell(st, (int)i + 2, &GHEN_BROWSE[i]) != SQLITE_OK) goto sqlfail;
if (sqlite3_step(st) != SQLITE_DONE) goto sqlfail;
sqlite3_finalize(st);
return 0;


sqlfail:
set_err(rep, "%s: %s", table, sqlite3_errmsg(db));
if (st) sqlite3_finalize(st);
return -1;
}

/* tbl_appinfo e global (nao tem usuario). INSERT OR IGNORE: nunca sobrescreve o que ja existe. */
static int insert_appinfo(sqlite3 *db, GhenReport *rep)
{
sqlite3_stmt *st = NULL;
if (sqlite3_prepare_v2(db,
"INSERT OR IGNORE INTO tbl_appinfo (titleId,key,val) VALUES (?1,?2,?3)",
-1, &st, NULL) != SQLITE_OK) goto sqlfail;
for (size_t i = 0; i < GHEN_INFO_N; i++) {
sqlite3_reset(st);
sqlite3_bind_text(st, 1, GHEN_TITLE_ID, -1, SQLITE_STATIC);
sqlite3_bind_text(st, 2, GHEN_INFO[i].name, -1, SQLITE_STATIC);
if (bind_cell(st, 3, &GHEN_INFO[i]) != SQLITE_OK) goto sqlfail;
if (sqlite3_step(st) != SQLITE_DONE) goto sqlfail;
rep->appinfo_rows += sqlite3_changes(db);
}
sqlite3_finalize(st);
return 0;

sqlfail:
set_err(rep, "tbl_appinfo: %s", sqlite3_errmsg(db));
if (st) sqlite3_finalize(st);
return -1;
}

int ghen_db_install(const char *dbPath, const char *onlyUser, GhenReport *rep)
{
sqlite3 *db = NULL;
FILE *probe;
char users[MAX_USERS][11];
int nusers, in_tx = 0, rc = -1, open_rc, open_errno;

memset(rep, 0, sizeof(*rep));

errno = 0;
probe = fopen(dbPath, "r+b");
if (!probe) {
    open_errno = errno;
    set_err(rep, "abertura direta r+b falhou: errno=%d (%s)", open_errno, strerror(open_errno));
    goto done;
}
fclose(probe);

errno = 0;
open_rc = sqlite3_open_v2(dbPath, &db, SQLITE_OPEN_READWRITE, NULL);
open_errno = errno;
if (open_rc != SQLITE_OK) {
    set_err(rep, "nao abriu %s: %s (sqlite=%d, errno=%d: %s; fopen r+b=ok)", dbPath,
            db ? sqlite3_errmsg(db) : "sem memoria", open_rc,
            open_errno, strerror(open_errno));
    goto done;
}
sqlite3_busy_timeout(db, 8000);   /* o SceShellCore tambem usa o banco */

nusers = list_users(db, users, MAX_USERS);
if (nusers < 0) { set_err(rep, "ler tabelas: %s", sqlite3_errmsg(db)); goto done; }
rep->users_found = nusers;
if (nusers == 0) { set_err(rep, "nenhuma tbl_appbrowse_* no app.db"); goto done; }

if (sqlite3_exec(db, "BEGIN IMMEDIATE", NULL, NULL, NULL) != SQLITE_OK) {
    set_err(rep, "BEGIN: %s", sqlite3_errmsg(db));
    goto done;
}
in_tx = 1;

for (int i = 0; i < nusers; i++) {
    char table[64];
    int ex;
    if (onlyUser && strcmp(onlyUser, users[i]) != 0) continue;
    rep->targets++;
    snprintf(table, sizeof(table), PFX "%.10s", users[i]);

    ex = entry_exists(db, table);
    if (ex < 0) { set_err(rep, "%s: %s", table, sqlite3_errmsg(db)); goto done; }
    if (ex == 1) { rep->existing++; continue; }         /* ja tem: so troca o icon0 (feito fora) */
    if (insert_browse(db, table, rep) != 0) goto done;
    rep->added++;
}

if (rep->targets == 0) {
    set_err(rep, "usuario %s nao tem tabela no app.db", onlyUser ? onlyUser : "?");
    goto done;
}

if (insert_appinfo(db, rep) != 0) goto done;

if (sqlite3_exec(db, "COMMIT", NULL, NULL, NULL) != SQLITE_OK) {
    set_err(rep, "COMMIT: %s", sqlite3_errmsg(db));
    goto done;
}
in_tx = 0;
rc = 0;


done:
if (in_tx) sqlite3_exec(db, "ROLLBACK", NULL, NULL, NULL);
if (db) sqlite3_close(db);
return rc;
}

int ghen_db_restore(void) {
char cmd[512];
snprintf(cmd, sizeof(cmd), "cp %s %s", BAK_PATH, DB_PATH);
return system(cmd);
}
