#include <stdint.h>

struct jailbreak_backup {
	uint32_t cr_uid;
	uint32_t cr_ruid;
	uint32_t cr_rgid;
	uint32_t cr_groups;
	uint64_t cr_paid;
	uint64_t cr_caps[2];
	void *cr_prison;
	void *fd_cdir;
	void *fd_jdir;
	void *fd_rdir;
};

enum {
	GOLDHEN_SYSCALL = 500,
	GOLDHEN_SDK_CMD_JAILBREAK = 2,
	GOLDHEN_SDK_CMD_UNJAILBREAK = 3
};

static struct jailbreak_backup saved_credentials;
static int jailbreak_active;

static int goldhen_command(uint64_t command, void *data)
{
	register uint64_t rax __asm__("rax") = 0;
	register uint64_t rdi __asm__("rdi") = GOLDHEN_SYSCALL;
	register uint64_t rsi __asm__("rsi") = command;
	register void *rdx __asm__("rdx") = data;
	unsigned char failed;

	__asm__ volatile("syscall\n\tsetc %0"
					 : "=m"(failed), "+a"(rax)
					 : "D"(rdi), "S"(rsi), "d"(rdx)
					 : "rcx", "r11", "memory");

	return failed ? -1 : (int)rax;
}

int ps4_jailbreak(void)
{
	int result;

	if (jailbreak_active)
		return 0;

	result = goldhen_command(GOLDHEN_SDK_CMD_JAILBREAK, &saved_credentials);
	if (result == 0)
		jailbreak_active = 1;

	return result;
}

int ps4_unjailbreak(void)
{
	int result;

	if (!jailbreak_active)
		return 0;

	result = goldhen_command(GOLDHEN_SDK_CMD_UNJAILBREAK, &saved_credentials);
	if (result == 0)
		jailbreak_active = 0;

	return result;
}
