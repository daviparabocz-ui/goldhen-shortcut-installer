/* GERADO por tools/gen_template.py a partir do app.db do usuario. Nao edite na mao. */
#ifndef GHEN_TEMPLATE_H
#define GHEN_TEMPLATE_H

#define GHEN_TITLE_ID "GHEN12349"

/* kind: 0 = TEXT, 1 = INTEGER. Colunas NULL no original ficam de fora (= NULL). */
typedef struct { const char *name; int kind; const char *s; long long i; } GhenCell;

static const GhenCell GHEN_BROWSE[] = {
    { "titleId", 0, "GHEN12349", 0 },
    { "contentId", 0, "IP9100-GHEN12349_00-SFPROD0000000000", 0 },
    { "titleName", 0, "★ Enable GoldHEN", 0 },
    { "metaDataPath", 0, "/user/appmeta/GHEN12349", 0 },
    { "lastAccessTime", 0, "2026-09-28 23:29:30.306", 0 },
    { "contentStatus", 1, 0, 0LL },
    { "onDisc", 1, 0, 2LL },
    { "parentalLevel", 1, 0, 0LL },
    { "visible", 1, 0, 1LL },
    { "sortPriority", 1, 0, 100LL },
    { "pathInfo", 1, 0, 0LL },
    { "lastAccessIndex", 1, 0, 14317LL },
    { "dispLocation", 1, 0, 5LL },
    { "canRemove", 1, 0, 1LL },
    { "category", 0, "gd", 0 },
    { "contentType", 1, 0, 0LL },
    { "pathInfo2", 1, 0, 0LL },
    { "presentBoxStatus", 1, 0, 0LL },
    { "entitlement", 1, 0, 1LL },
    { "thumbnailUrl", 0, "/user/appmeta/GHEN12349icon0.png", 0 },
    { "lastUpdateTime", 0, "2021-02-13 18:19:29.747", 0 },
    { "playableDate", 0, "", 0 },
    { "contentSize", 1, 0, 0LL },
    { "installDate", 0, "2019-08-08 19:47:12.333", 0 },
    { "platform", 1, 0, 0LL },
    { "uiCategory", 0, "app", 0 },
    { "skuId", 0, "", 0 },
    { "disableLiveDetail", 1, 0, 0LL },
    { "linkType", 1, 0, 5LL },
    { "linkUri", 0, "psmodalwebbrowser:load?parental=True&signup=False&url=http://webkitty.arabpixel.net", 0 },
};

/* tbl_appinfo: (titleId, key, val); o tipo de val e preservado como no original. */
static const GhenCell GHEN_INFO[] = {
    { "#_access_index", 1, 0, 55157LL },
    { "#_contents_status", 0, "0", 0 },
    { "#_last_access_time", 0, "2026-10-04 14:41:05.419", 0 },
    { "#_mtime", 0, "2021-04-16 17:13:08.529", 0 },
    { "#_promote_time", 0, "2021-04-16 16:48:08.858", 0 },
    { "#_update_index", 0, "313", 0 },
    { "#exit_type", 0, "0", 0 },
    { "ATTRIBUTE", 0, "0", 0 },
    { "ATTRIBUTE_INTERNAL", 0, "68", 0 },
    { "CATEGORY", 0, "gdi", 0 },
    { "CONTENT_ID", 0, "", 0 },
    { "DISP_LOCATION_1", 0, "-1", 0 },
    { "DISP_LOCATION_2", 0, "4", 0 },
    { "PT_PARAM", 0, "0", 0 },
    { "TITLE", 0, "Name App", 0 },
    { "TITLE_02", 0, "Name App", 0 },
    { "TITLE_07", 0, "Name App", 0 },
    { "TITLE_17", 0, "Name App", 0 },
    { "TITLE_22", 0, "Name App", 0 },
    { "TITLE_ID", 0, "GHEN12349", 0 },
    { "USER_DEFINED_PARAM_1", 0, "0", 0 },
    { "USER_DEFINED_PARAM_2", 0, "0", 0 },
    { "USER_DEFINED_PARAM_3", 0, "0", 0 },
    { "USER_DEFINED_PARAM_4", 0, "0", 0 },
    { "_contents_location", 0, "2", 0 },
    { "_current_slot", 0, "0", 0 },
    { "_disable_live_detail", 0, "0", 0 },
    { "_hdd_location", 0, "0", 0 },
    { "_metadata_path", 0, "/user/appmeta/GHEN12349", 0 },
    { "_org_path", 0, "/user/app/GHEN12349", 0 },
    { "_path_info", 0, "4325508", 0 },
    { "_path_info_2", 0, "18577915398586368", 0 },
    { "_sort_priority", 0, "100", 0 },
    { "_uninstallable", 0, "1", 0 },
    { "_view_category", 0, "1", 0 },
    { "_working_status", 0, "0", 0 },
};

#define GHEN_BROWSE_N (sizeof(GHEN_BROWSE)/sizeof(GHEN_BROWSE[0]))
#define GHEN_INFO_N   (sizeof(GHEN_INFO)/sizeof(GHEN_INFO[0]))

#endif
