/*
 * GoldHEN Shortcut Installer — PS4 (OpenOrbis)
 *  X = so o usuario atual | Quadrado = todos os usuarios | Circulo = sair
 * Fluxo: root/jailbreak -> backup do app.db -> ghen_db_install() -> troca o icon0 -> avisos.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>

#include <stdarg.h>
#include "ghen_db.h"
#include "ghen_template.h"

/* Prototipos por alias de simbolo: nao brigam com os headers do toolchain. */
extern int  p_notify(int dev, void *req, size_t sz, int blk) __asm__("sceKernelSendNotificationRequest");
extern int  p_usleep(unsigned us)                            __asm__("sceKernelUsleep");
extern int  p_user_init(void *p)                             __asm__("sceUserServiceInitialize");
extern int  p_user_fg(int *id)                               __asm__("sceUserServiceGetForegroundUser");
extern int  p_user_init_user(int *id)                        __asm__("sceUserServiceGetInitialUser");
extern int  p_pad_init(void)                                 __asm__("scePadInit");
extern int  p_pad_open(int user, int type, int idx, void *p) __asm__("scePadOpen");
extern int  p_pad_read(int h, void *data)                    __asm__("scePadReadState");
extern int  ps4_jailbreak(void);

#define DB_PATH   "/system_data/priv/mms/app.db"
#define BAK_DIR   "/data/GHEN_Shortcut"
#define BAK_PATH  BAK_DIR "/app.db.bak"
#define META_DIR  "/user/appmeta/" GHEN_TITLE_ID
#define ICON_SRC  "/app0/assets/icon0.png"
#define ICON_DST  META_DIR "/icon0.png"

#define BTN_CIRCLE 0x2000u
#define BTN_CROSS  0x4000u
#define BTN_SQUARE 0x8000u

typedef struct {
    int type, reqId, priority, msgId, targetId, userId, unk1, unk2, appId, errorNum, unk3;
    unsigned char useIconImageUri;
    char message[1024], iconUri[1024], unk[1024];
} NotifReq;

static void toast(const char *fmt, ...)
{
    static NotifReq r;
    va_list ap;
    memset(&r, 0, sizeof(r));
    r.type = 0; r.targetId = -1;
    va_start(ap, fmt);
    vsnprintf(r.message, sizeof(r.message), fmt, ap);
    va_end(ap);
    p_notify(0, &r, sizeof(r), 0);
}

static int copy_file(const char *src, const char *dst)
{
    char tmp[256];
    FILE *in = fopen(src, "rb"), *out;
    char buf[8192];
    size_t n;
    if (!in) return -1;
    snprintf(tmp, sizeof(tmp), "%s.tmp", dst);
    out = fopen(tmp, "wb");
    if (!out) { fclose(in); return -2; }
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
        if (fwrite(buf, 1, n, out) != n) { fclose(in); fclose(out); remove(tmp); return -3; }
    fclose(in);
    fclose(out);
    remove(dst);
    return rename(tmp, dst);
}

static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }

static int pick_mode(int userId)
{
    static unsigned char padbuf[1024] __attribute__((aligned(16)));
    int h, waited = 0;

    p_pad_init();
    h = p_pad_open(userId, 0, 0, NULL);
    if (h < 0) { toast("Pad nao abriu (0x%x)", h); return 0; }

    while (waited < 180000) {                 /* ~3 min e sai */
        if (waited % 9000 == 0)
            toast("GoldHEN Shortcut Installer\nX = so este usuario\nQuadrado = todos os usuarios\nCirculo = sair");
        memset(padbuf, 0, 64);
        if (p_pad_read(h, padbuf) >= 0) {
            uint32_t b = *(uint32_t *)padbuf;   /* ScePadData.buttons e o 1o campo */
            if (b & BTN_CROSS)  return 1;
            if (b & BTN_SQUARE) return 2;
            if (b & BTN_CIRCLE) return 0;
        }
        p_usleep(50000);
        waited += 50;
    }
    return 0;
}

int main(void)
{
    int userId = -1, mode;
    char suffix[11];
    GhenReport rep;

    p_user_init(NULL);
    if (p_user_fg(&userId) < 0 || userId <= 0) p_user_init_user(&userId);

    if (ps4_jailbreak() < 0)
        toast("Aviso: jailbreak nao configurado; vou tentar mesmo assim.");

    mode = pick_mode(userId);
    if (mode == 0) { toast("Cancelado."); return 0; }

    if (!exists(DB_PATH)) { toast("Sem acesso ao app.db (jailbreak/permissao?)"); return 1; }

    /* backup so na primeira vez: guarda o app.db original */
    mkdir(BAK_DIR, 0777);
    if (!exists(BAK_PATH) && copy_file(DB_PATH, BAK_PATH) != 0) {
        toast("Falhou o backup do app.db. Nada foi alterado.");
        return 1;
    }

    ghen_user_suffix(userId, suffix);
    if (ghen_db_install(DB_PATH, mode == 1 ? suffix : NULL, &rep) != 0) {
        toast("Erro no app.db: %s\nNada foi alterado.", rep.err);
        return 1;
    }

    /* icon0: sempre troca (a pasta appmeta e compartilhada por todos os usuarios) */
    mkdir("/user/appmeta", 0777);
    mkdir(META_DIR, 0777);
    if (copy_file(ICON_SRC, ICON_DST) != 0) {
        toast("Atalho ok, mas falhou ao gravar o icon0.png");
        return 1;
    }

    toast("Pronto!\nNovos: %d | ja existiam (so icone): %d\nReinicie o PS4 por completo para ver o atalho.",
          rep.added, rep.existing);
    p_usleep(4000000);
    return 0;
}
