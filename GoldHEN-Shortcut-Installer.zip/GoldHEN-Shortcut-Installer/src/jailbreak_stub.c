/* Ponto de encaixe do jailbreak (escape do sandbox + root).
 * Aqui so tem um stub FRACO. Para o app escrever em /system_data/priv/mms/app.db voce precisa de
 * acesso fora do sandbox: defina "int ps4_jailbreak(void)" no mesmo metodo que seus outros
 * homebrews usam no seu firmware/GoldHEN (retorne 0 em sucesso) e esse stub e ignorado. */
__attribute__((weak)) int ps4_jailbreak(void) { return -1; }
