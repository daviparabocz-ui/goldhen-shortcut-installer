#!/bin/sh
# Baixa o amalgamation do SQLite (3.45.1, a mesma versao que escreveu o seu app.db)
set -e
mkdir -p third_party/sqlite && cd third_party/sqlite
curl -L -o s.zip https://www.sqlite.org/2024/sqlite-amalgamation-3450100.zip
unzip -jo s.zip '*/sqlite3.c' '*/sqlite3.h' && rm s.zip
