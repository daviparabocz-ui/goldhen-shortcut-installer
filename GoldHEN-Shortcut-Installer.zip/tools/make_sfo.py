#!/usr/bin/env python3
"""Gera sce_sys/param.sfo (formato PSF) do instalador. Uso: python3 tools/make_sfo.py"""
import struct
TITLE_ID="GHEN00001"; CONTENT_ID="IV0000-GHEN00001_00-GOLDHENSHORTCUT0"
E=[("APP_TYPE","i",0,4),("APP_VER","s","01.00",8),("ATTRIBUTE","i",0,4),("CATEGORY","s","gd",4),
   ("CONTENT_ID","s",CONTENT_ID,48),("DOWNLOAD_DATA_SIZE","i",0,4),("FORMAT","s","obs",4),
   ("PARENTAL_LEVEL","i",1,4),("PUBTOOLINFO","s","c_date=20261012",512),("SYSTEM_VER","i",0,4),
   ("TITLE","s","GoldHEN Shortcut Installer",128),("TITLE_ID","s",TITLE_ID,12),("VERSION","s","01.00",8)]
E.sort(key=lambda e:e[0])
keys=b"";ents=b"";data=b""
for k,t,v,mx in E:
    ko=len(keys);keys+=k.encode()+b"\0"
    if t=="i": raw=struct.pack("<I",v);fmt=0x0404;ln=4
    else: raw=v.encode()+b"\0";fmt=0x0204;ln=len(raw)
    ents+=struct.pack("<HHIII",ko,fmt,ln,mx,len(data)); data+=raw.ljust(mx,b"\0")
while len(keys)%4: keys+=b"\0"
ko=20+len(ents); do=ko+len(keys)
open("sce_sys/param.sfo","wb").write(struct.pack("<4sIIII",b"\0PSF",0x101,ko,do,len(E))+ents+keys+data)
print("ok sce_sys/param.sfo", CONTENT_ID)
