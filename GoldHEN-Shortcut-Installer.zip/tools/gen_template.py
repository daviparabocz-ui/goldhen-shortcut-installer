#!/usr/bin/env python3
"""
Gera src/ghen_template.h a partir de um app.db real (o seu).
Copia EXATAMENTE as linhas do titleId (GHEN12349) de tbl_appbrowse_* e tbl_appinfo.

Uso:  python3 tools/gen_template.py caminho/do/app.db [GHEN12349]
"""
import sqlite3, sys, collections

db_path = sys.argv[1]
title = sys.argv[2] if len(sys.argv) > 2 else "GHEN12349"
c = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)

tabs = [r[0] for r in c.execute(
    "select name from sqlite_master where name like 'tbl_appbrowse_%' order by name")]

variants = collections.OrderedDict()
for t in tabs:
    cur = c.execute(f"select * from {t} where titleId=?", (title,))
    cols = [d[0] for d in cur.description]
    row = cur.fetchone()
    if row is None:
        continue
    key = tuple(zip(cols, row))
    variants.setdefault(key, []).append(t)

if not variants:
    sys.exit(f"{title} nao encontrado em nenhuma tbl_appbrowse_*")

best = max(variants.items(), key=lambda kv: len(kv[1]))
print(f"[i] {len(variants)} variante(s) da linha; usando a mais comum ({len(best[1])} tabelas)")
if len(variants) > 1:
    base = dict(best[0])
    for key, tl in variants.items():
        if key is best[0]:
            continue
        diff = [k for k, v in key if base[k] != v]
        print(f"    diferem em {tl}: {diff}")

def cstr(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n') + '"'

out = []
out.append("/* GERADO por tools/gen_template.py a partir do app.db do usuario. Nao edite na mao. */")
out.append("#ifndef GHEN_TEMPLATE_H\n#define GHEN_TEMPLATE_H\n")
out.append(f'#define GHEN_TITLE_ID "{title}"\n')
out.append("/* kind: 0 = TEXT, 1 = INTEGER. Colunas NULL no original ficam de fora (= NULL). */")
out.append("typedef struct { const char *name; int kind; const char *s; long long i; } GhenCell;\n")

out.append("static const GhenCell GHEN_BROWSE[] = {")
for k, v in best[0]:
    if v is None:
        continue
    if isinstance(v, int):
        out.append(f'    {{ {cstr(k)}, 1, 0, {v}LL }},')
    else:
        out.append(f'    {{ {cstr(k)}, 0, {cstr(v)}, 0 }},')
out.append("};\n")

out.append("/* tbl_appinfo: (titleId, key, val); o tipo de val e preservado como no original. */")
out.append("static const GhenCell GHEN_INFO[] = {")
n = 0
for k, v, t in c.execute(
        "select key,val,typeof(val) from tbl_appinfo where titleId=? order by key", (title,)):
    n += 1
    if t == "integer":
        out.append(f'    {{ {cstr(str(k))}, 1, 0, {v}LL }},')
    else:
        out.append(f'    {{ {cstr(str(k))}, 0, {cstr(str(v))}, 0 }},')
out.append("};\n")
out.append("#define GHEN_BROWSE_N (sizeof(GHEN_BROWSE)/sizeof(GHEN_BROWSE[0]))")
out.append("#define GHEN_INFO_N   (sizeof(GHEN_INFO)/sizeof(GHEN_INFO[0]))\n")
out.append("#endif")

open("src/ghen_template.h", "w", encoding="utf-8").write("\n".join(out) + "\n")
print(f"[ok] src/ghen_template.h  ({len(best[0])} colunas no appbrowse, {n} chaves no appinfo)")
